﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    internal class students
    {
        private int numOfstudents;
        private string name;
        private double StudentNumber;
        private string NumberOfModules;

        public NumOfstudents()
        {
        }

        public NumOfStudents(int numOfStudents, string name, StudentNumber, string NumberOfMOdules)
        {
            this.NumOfStudents = numOfStudents;
            this.Name = name;
            this.StudentNumber = StudentNumber;
            this.NumberOfModules = NumberOfModules;
        }

        public int NumOfStudents { get => numOfStudents; set => numOfStudents= value; }
        public int NumberOfStudents { get; }
        public string Name { get => name; set => name = value; }
        public double StudentNumber { get => StudentNumber; set => StudentNumber = value; }
        public string NumberOfModules { get => NumberOfModules; set => NumberOfModules = value; }

        public override bool Equals(object? obj)
        {
            return obj is students students &&
                   numOfstudents == students.numOfstudents &&
                   name == students.name &&
                   studentNumber == students.studentNumber &&
                   NumberOfModules == students.NumberOfModules;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(numOfstudents, name, studentNumber, NumberOfModules);
        }
    }
}


    }
}
