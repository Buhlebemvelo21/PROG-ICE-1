﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    internal class modules
    {
        private int numberOfmodules;
        private string description;
        private int numOfmodules;

        public numofmodules()
        {

        }

        public numofmodules(int numOfmodules, string description)
        {
            this.NumberOfModules = numOfmodules;
            this.Description = description;
        }

        public int NumOfmodules { get => numOfmodules; set => numOfmodules = value; }
        public int NumberOfModules { get; private set; }
        public string Description { get => description; set => description = value; }
    }
}

    }
}
