﻿internal class NumOfStudents
{
    public static implicit operator NumOfStudents(Students v)
    {
        throw new NotImplementedException();
    }
}