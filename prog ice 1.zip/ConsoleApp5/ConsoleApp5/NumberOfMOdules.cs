﻿internal class NumberOfMOdules
{
    public NumberOfMOdules()
    {
    }
}