﻿internal class StudentsUsed
{
    public static implicit operator StudentsUsed(Students v)
    {
        throw new NotImplementedException();
    }
}