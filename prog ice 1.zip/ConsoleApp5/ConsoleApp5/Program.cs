﻿public static int NumOfStudents { get; private set; }


public static void Main(string[] args)
{
    const int MAX = 10;

    NumOfStudents[] stud = new Students[MAX]; 
    NumberOfModules[] mod = new NumberOfModules[MAX];

    int n;
    string confirm;

    /* Console.WriteLine("NUMBER OF Studets USED?");
     n = int.Parse(Console.ReadLine());*/

    for (int i = 0; i < MAX; i++)
    {
        stud[i] = new Students();
        mod[i] = new NumberOfMOdules();

        Console.WriteLine("how many students do you wish to input ");
        stud[i].NumOfStudents = Convert.ToInt32(Console.ReadLine());

        Console.WriteLine("Please enter name of Student ");
        stud[i].Name = Console.ReadLine();

        Console.WriteLine("Please enter student number ");
        stud[i].studentNumber = Convert.ToDouble(Console.ReadLine());

        Console.WriteLine("Please enter number of modules  ");
        mod[i].NumOfModules = Console.ReadLine();

        Console.WriteLine("Please enter the list of modules the student is doing ");
        mod[i].Modules = Convert.ToInt32(Console.ReadLine());

       

        }
        Console.WriteLine("Please print a report for each student");
        confirm = Console.ReadLine().ToString();

        if (confirm == "YES")
        {
            Console.Clear();
        }
        else
        {
            Console.WriteLine("you are wellcome to use an array/array list");
        }
    }
}
internal class NumofStudents
{
}

internal class NumberOfModules
{
    public static implicit operator NumberOfModules(NumberOfMOdules v)
    {
        throw new NotImplementedException();
    }
}